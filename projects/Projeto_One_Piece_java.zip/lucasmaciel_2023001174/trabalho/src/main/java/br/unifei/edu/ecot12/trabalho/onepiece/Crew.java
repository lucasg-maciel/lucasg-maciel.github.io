package br.unifei.edu.ecot12.trabalho.onepiece;

import java.util.ArrayList;
import java.util.List;

public class Crew {
    private String crewName;
    private String shipName;
    private int crewBounty;
    private int crewSize;
    private Pirate Captain;
    private List<Pirate> members = new ArrayList<Pirate>();
    private Island currentIsland;

    public void calculateCrewBounty(){
        crewBounty = 0;
        for (Pirate m : members) {
            crewBounty += m.getBounty();
            
        }
    }

    public void calculateCrewSize(){
        crewSize = 0;
        for (Pirate m : members) {
            crewSize ++;
        }
    }

    public void setSail(Island destination){
        currentIsland = destination;
        for (Pirate m : members) {
            m.setHealth(m.getHealthMax());
        }

    }

    public String getCrewName() {
        return crewName;
    }

    public void setCrewName(String crewName) {
        this.crewName = crewName;
    }

    public String getShipName() {
        return shipName;
    }

    public void setShipName(String shipName) {
        this.shipName = shipName;
    }

    public int getCrewBounty() {
        return crewBounty;
    }

    public int getCrewSize() {
        return crewSize;
    }

    public Pirate getCaptain() {
        return Captain;
    }

    public void setCaptain(Pirate Captain) {
        this.Captain = Captain;
    }

    public List<Pirate> getMembers() {
        return members;
    }

    public void setMembers(List<Pirate> members) {
        this.members = members;
    }

    public Island getCurrentIsland() {
        return currentIsland;
    }

    public void setCurrentIsland(Island currentIsland) {
        this.currentIsland = currentIsland;
    }



}
