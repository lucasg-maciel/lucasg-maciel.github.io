package br.unifei.edu.ecot12.trabalho.onepiece;

public class Zoan extends AkumaNoMi{
    private String animal;
    private int durability;

    public void transform(){
        if(getUser() != null){
            System.out.println(getUser().getName() + " has transformed into a " + this.animal);
            getUser().setHealth(durability*2);
        }
    }

    public String getAnimal() {
        return animal;
    }

    public void setAnimal(String animal) {
        this.animal = animal;
    }

    public int getDurability() {
        return durability;
    }

    public void setDurability(int durability) {
        this.durability = durability;
    }

}
