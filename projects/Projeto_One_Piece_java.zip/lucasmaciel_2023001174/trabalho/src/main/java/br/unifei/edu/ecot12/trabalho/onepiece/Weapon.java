package br.unifei.edu.ecot12.trabalho.onepiece;

public class Weapon {
    private  int durability;
    private Human owner;

    public void repair(){
        durability = 100;
    }

    public void attack(Human opponent){
        System.out.println(owner.getName() + " deals " + (owner.getStrength() * 2) + " damage!");
        opponent.takeDamage(owner.getStrength()* 2);
        durability -= 5;
    }

    public int getDurability() {
        return durability;
    }

    public void setDurability(int durability) {
        this.durability = durability;
    }

    public Human getOwner() {
        return owner;
    }

    public void setOwner(Human owner) {
        this.owner = owner;
    }


}
