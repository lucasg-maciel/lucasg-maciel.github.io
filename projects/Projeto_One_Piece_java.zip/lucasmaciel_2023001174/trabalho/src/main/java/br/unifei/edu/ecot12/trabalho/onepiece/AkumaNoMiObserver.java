package br.unifei.edu.ecot12.trabalho.onepiece;

public class AkumaNoMiObserver implements Observer{

    @Override
    public void respawnFruit(AkumaNoMi fruit) {
        fruit.getUser().setFruit(null);
        fruit.setUser(null);
    }
    
}
