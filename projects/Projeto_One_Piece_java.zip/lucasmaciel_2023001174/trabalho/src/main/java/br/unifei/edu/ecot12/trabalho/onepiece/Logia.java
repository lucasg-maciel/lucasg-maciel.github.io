package br.unifei.edu.ecot12.trabalho.onepiece;

public class Logia extends AkumaNoMi{
    private String element;

    public  void becomeElement(){
        if(getUser() != null){
        getUser().setStrength(getUser().getStrength()*2);
        }
    }

    public String getElement() {
        return element;
    }

    public void setElement(String element) {
        this.element = element;
    }


}
