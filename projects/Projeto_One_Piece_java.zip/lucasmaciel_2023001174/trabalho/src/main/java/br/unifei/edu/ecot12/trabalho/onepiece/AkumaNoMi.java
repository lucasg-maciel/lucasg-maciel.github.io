/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package br.unifei.edu.ecot12.trabalho.onepiece;


public abstract  class AkumaNoMi {
    private String fruitName;
    private Human user;

    public String getFruitName() {
        return fruitName;
    }

    public void setFruitName(String fruitName) {
        this.fruitName = fruitName;
    }

    public Human getUser() {
        return user;
    }

    public void setUser(Human user) {
        this.user = user;
    }

}
