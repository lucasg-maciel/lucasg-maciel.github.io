package br.unifei.edu.ecot12.trabalho.onepiece;

public class OnePiece {
    private static OnePiece instance = new OnePiece();

    private String description;

    private OnePiece(){}

    public static OnePiece getInstance() {
        return instance;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }



}
