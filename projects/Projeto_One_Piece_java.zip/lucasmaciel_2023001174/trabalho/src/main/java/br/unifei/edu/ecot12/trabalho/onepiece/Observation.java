package br.unifei.edu.ecot12.trabalho.onepiece;

public class Observation extends Haki{

    public void sensePower(Human opponent){
        System.out.println(opponent.getName() + " strength is " + opponent.getStrength() + " and opponent's health is " + opponent.getHealth());
        System.out.println();
    }
}
