package br.unifei.edu.ecot12.trabalho.onepiece;

public class Marine extends Human{
    private String rank;

    public String getRank() {
        return rank;
    }

    public void setRank(String rank) {
        this.rank = rank;
    }

}
