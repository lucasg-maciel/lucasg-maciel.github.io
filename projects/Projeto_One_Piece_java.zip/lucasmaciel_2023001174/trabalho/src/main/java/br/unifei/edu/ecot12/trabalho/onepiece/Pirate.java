package br.unifei.edu.ecot12.trabalho.onepiece;

public class Pirate extends Human{
    private long bounty;

    public void increaseBounty(Pirate defeated){
        long increase = defeated.bounty;
        bounty += (long) (increase * 0.7);
    }

    public long getBounty() {
        return bounty;
    }

    public void setBounty(int bounty) {
        this.bounty = bounty;
    }

    
}
