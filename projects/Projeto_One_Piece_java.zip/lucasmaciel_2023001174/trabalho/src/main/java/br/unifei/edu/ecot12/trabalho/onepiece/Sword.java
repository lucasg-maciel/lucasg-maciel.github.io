package br.unifei.edu.ecot12.trabalho.onepiece;

public class Sword extends Weapon{
    private String grade;
    private int sharpness;

    public String getGrade() {
        return grade;
    }

    public void setGrade(String grade) {
        this.grade = grade;
    }

    public int getSharpness() {
        return sharpness;
    }

    public void setSharpness(int sharpness) {
        this.sharpness = sharpness;
    }


}
