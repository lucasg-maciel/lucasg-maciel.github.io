package br.unifei.edu.ecot12.trabalho.onepiece;

public class Conqueror extends Haki{
    public void dominate(Human opponent){
        if(getUser().getWillPower() > (opponent.getWillPower() * 5)){
            System.out.println(opponent.getName() + " has fainted.");
        }
        else if(getUser().getWillPower() > opponent.getWillPower() && getUser().getWillPower() < (opponent.getWillPower() * 5)){
            System.out.println(opponent.getName() + " was intimidated by " + getUser().getName());
            opponent.setStrength(opponent.getStrength()/2);
        }
    }
}
