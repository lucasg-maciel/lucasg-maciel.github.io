package br.unifei.edu.ecot12.trabalho.onepiece;

public abstract  class  Haki {
    private int proficiency;
    private Human user;

    public int getProficiency() {
        return proficiency;
    }

    public void setProficiency(int proficiency) {
        this.proficiency = proficiency;
    }

    public Human getUser() {
        return user;
    }

    public void setUser(Human user) {
        this.user = user;
    }

}
