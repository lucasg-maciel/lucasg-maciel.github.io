/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package br.unifei.edu.ecot12.trabalho.onepiece;


public class Island {
    private String name;
    private String climate;
    private String location;
    private String ruler;
    private String rulerFaction;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getClimate() {
        return climate;
    }

    public void setClimate(String climate) {
        this.climate = climate;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getRuler() {
        return ruler;
    }

    public void setRuler(String ruler) {
        this.ruler = ruler;
    }

    public String getRulerFaction() {
        return rulerFaction;
    }

    public void setRulerFaction(String rulerFaction) {
        this.rulerFaction = rulerFaction;
    }


}
