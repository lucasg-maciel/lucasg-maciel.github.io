package br.unifei.edu.ecot12.trabalho.onepiece;

import java.util.ArrayList;
import java.util.List;

public class Human {
    private String name;
    private int age;
    private String race;
    private boolean isAlive;
    private int strength;
    private int health;
    private int healthMax;
    private int willPower;
    private List<Observer> observers = new ArrayList<>();
    private AkumaNoMi fruit;
    private Haki[] hakis;
    private Weapon ownedWeapon;



    public Human() {
        this.hakis = new Haki[3];
    }



    public int attack() {
        int damage = strength;
        System.out.println(name + " deals " + damage + " damage!");
        return damage;
    }

    public void takeDamage(int damage) {
        health -= damage;
        if(health < 0){
            health = 0;
        }
        System.out.println(name + " takes " + damage + " damage.");
        System.out.println(name + " remaining health: " + health);
        System.out.println();
        if (health <= 0) {
            health = 0;
            System.out.println(name + " has died!");
            System.out.println();
            isAlive = false;
            if (fruit != null) {
                notifyDeath();
            }
        }
    }
    
    public void fight(Human opponent) {
        int damageTaken = this.attack();
        opponent.takeDamage(damageTaken);
    }
    
    protected  void notifyDeath() {
        for (Observer o : observers) {
            o.respawnFruit(fruit);
        }
    }
    public void eatFruit(AkumaNoMi fruit) {
        this.fruit = fruit;
        fruit.setUser(this);
    }
    



    
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getRace() {
        return race;
    }

    public void setRace(String race) {
        this.race = race;
    }

    public boolean isIsAlive() {
        return isAlive;
    }

    public void setIsAlive(boolean isAlive) {
        this.isAlive = isAlive;
    }

    public int getStrength() {
        return strength;
    }

    public void setStrength(int strength) {
        this.strength = strength;
    }

    public int getHealth() {
        return health;
    }

    public void setHealth(int health) {
        this.health = health;
    }

    public List<Observer> getObservers() {
        return observers;
    }

    public void setObservers(List<Observer> observers) {
        this.observers = observers;
    }

    public AkumaNoMi getFruit() {
        return fruit;
    }
    
    public void setFruit(AkumaNoMi fruit) {
        this.fruit = fruit;
    }

    public void setHakis(int slot, Haki haki) {
        if (slot >= 0 && slot < 3) {
            hakis[slot] = haki;
        }
    }

    public Haki getHakis(int slot) {
        if (slot >= 0 && slot < 3) {
            return hakis[slot];
        }
        else{
            return null;
        }
    }

    public int getWillPower() {
        return willPower;
    }

    public void setWillPower(int willPower) {
        this.willPower = willPower;
    }

    public Weapon getOwnedWeapon() {
        return ownedWeapon;
    }

    public void setOwnedWeapon(Weapon ownedWeapon) {
        this.ownedWeapon = ownedWeapon;
    }

    public int getHealthMax() {
        return healthMax;
    }

    public void setHealthMax(int healthMax) {
        this.healthMax = healthMax;
    }



}
