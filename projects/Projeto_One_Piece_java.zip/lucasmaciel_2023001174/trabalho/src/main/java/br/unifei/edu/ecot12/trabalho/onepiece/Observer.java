package br.unifei.edu.ecot12.trabalho.onepiece;

public interface Observer {

    public void respawnFruit(AkumaNoMi fruit);

}
