package br.unifei.edu.ecot12.trabalho.onepiece;

public class Main {
    public static void main(String[] args) {

        Sea east = new Sea();
        east.setName("East Blue");
        east.setDangerLevel("low");

        Island dawn = new Island();
        dawn.setName("Dawn Island");
        dawn.setLocation("East Blue");

        Pirate arlong = new Pirate();
        arlong.setAge(39);
        arlong.setBounty(20000000);
        arlong.setHealth(75);
        arlong.setIsAlive(true);
        arlong.setRace("Fishmen");
        arlong.setStrength(15);
        arlong.setName("Arlong");

        Island park = new Island();
        park.setLocation("East Blue");
        park.setName("Arlong Park");
        park.setRuler("Arlong");
        park.setRulerFaction("Pirate");

        east.getIslands().add(park);
        east.getIslands().add(dawn);


        Paramecia gomu = new Paramecia();
        gomu.setFruitName("gomu gomu no mi"); 
        gomu.setPowerDescription("User's body becomes rubber");

        AkumaNoMiObserver o = new AkumaNoMiObserver();
        
        Pirate luffy = new Pirate();
        luffy.setName("Monkey D. Luffy");
        luffy.setAge(17);
        luffy.setHealth(100);
        luffy.setRace("Human");
        luffy.setStrength(35);
        luffy.setIsAlive(true);
        luffy.setWillPower(115);
        luffy.setHealthMax(100);

        luffy.eatFruit(gomu);
        luffy.getObservers().add(o);

        Sword kitetsu = new Sword();
        kitetsu.setGrade("o wazamono");
        kitetsu.setSharpness(50);
        kitetsu.setDurability(100);
        
        Pirate zoro = new Pirate();
        zoro.setName("Roronoa Zoro");
        zoro.setAge(19);
        zoro.setHealth(100);
        zoro.setRace("Human");
        zoro.setStrength(25);
        zoro.setIsAlive(true);
        zoro.setWillPower(25);
        kitetsu.setOwner(zoro);
        zoro.setOwnedWeapon(kitetsu);
        zoro.setHealthMax(100);

        Pirate nami = new Pirate();
        nami.setAge(17);
        nami.setName("Nami");
        nami.setRace("Human");
        nami.setStrength(15);
        nami.setIsAlive(true);
        nami.setHealth(50);
        nami.setWillPower(20);
        nami.setHealthMax(50);



        Pirate usopp = new Pirate();
        usopp.setAge(17);
        usopp.setName("Usopp");
        usopp.setRace("Human");
        usopp.setStrength(15);
        usopp.setHealth(60);
        usopp.setIsAlive(true);
        usopp.setWillPower(25);
        usopp.setHealthMax(60);

        FireArm slingshot = new FireArm();
        slingshot.setOwner(usopp);
        slingshot.setDurability(100);
        slingshot.setAmmo(1);
        slingshot.setAmmoCapacity(1);
        slingshot.setPenetration(15);

        usopp.setOwnedWeapon(slingshot);

        Pirate sanji = new Pirate();
        sanji.setAge(19);
        sanji.setName("Vinsmoke Sanji");
        sanji.setRace("Human");
        sanji.setHealth(100);
        sanji.setIsAlive(true);
        sanji.setStrength(25);
        sanji.setWillPower(25);
        sanji.setHealthMax(100);

        Crew strawhat = new Crew();
        strawhat.setCaptain(luffy);
        strawhat.setCrewName("Strawhat crew");
        strawhat.setCurrentIsland(dawn);
        strawhat.setShipName("Merry");
        strawhat.getMembers().add(nami);
        strawhat.getMembers().add(luffy);
        strawhat.getMembers().add(sanji);
        strawhat.getMembers().add(zoro);
        strawhat.getMembers().add(usopp);

        strawhat.calculateCrewSize();
        System.out.println();
        System.out.println(strawhat.getCaptain().getName() + " formed the crew: " + strawhat.getCrewName() + " with " + strawhat.getCrewSize() + " members");

        strawhat.setSail(park);

        System.out.println("The " + strawhat.getCrewName() + " has arrived at" + strawhat.getCurrentIsland().getName());
        System.out.println();

        luffy.fight(arlong);
        arlong.fight(luffy);
        zoro.fight(arlong);
        slingshot.fire(arlong);
        slingshot.reload();


        luffy.setBounty(30000000);

        System.out.println(luffy.getName() + " defeated " + arlong.getName() + " and has received bounty of " + luffy.getBounty() + " Berries");
        System.out.println();

        Sea grand = new Sea();
        grand.setDangerLevel("high");
        grand.setClimateBehavior("unpredictable");
        grand.setName("Grand Line");

        Island alabasta = new Island();
        alabasta.setClimate("desert");
        alabasta.setName("Alabasta");
        alabasta.setRuler("King Cobra");
        alabasta.setRulerFaction("World Government");
        alabasta.setLocation("Grand Line");

        Pirate crocodile = new Pirate();
        crocodile.setAge(44);
        crocodile.setBounty(81000000);
        crocodile.setHealthMax(80);
        crocodile.setHealth(80);
        crocodile.setIsAlive(true);
        crocodile.setName("Crocodile");
        crocodile.setStrength(20);
        crocodile.setRace("Human");
        crocodile.setWillPower(25);

        Logia suna = new Logia();
        suna.setFruitName("Suna Suna no mi");
        suna.setElement("Sand");

        crocodile.eatFruit(suna);

        AkumaNoMiObserver o2 = new AkumaNoMiObserver();

        crocodile.getObservers().add(o2);

        strawhat.setSail(alabasta);

        Pirate chopper = new Pirate();
        chopper.setAge(15);
        chopper.setHealth(40);
        chopper.setHealthMax(40);
        chopper.setRace("Deer");
        chopper.setStrength(5);
        chopper.setWillPower(15);
        chopper.setIsAlive(true);
        chopper.setName("Tony Tony Chopper");

        Zoan hito = new Zoan();
        hito.setAnimal("Human");
        hito.setDurability(20);
        hito.setFruitName("Hito Hito no mi");
        
        chopper.eatFruit(hito);

        AkumaNoMiObserver o3 = new AkumaNoMiObserver();

        chopper.getObservers().add(o3);


        Pirate robin = new Pirate();
        robin.setAge(28);
        robin.setBounty(80000000);
        robin.setHealthMax(75);
        robin.setHealth(75);
        robin.setIsAlive(true);
        robin.setName("Nico Robin");
        robin.setRace("Human");
        robin.setWillPower(20);
        robin.setStrength(15);

        Paramecia hana = new Paramecia();
        hana.setFruitName("Hana Hana no mi");
        hana.setPowerDescription("Can grow parts of the user body");
        

        robin.eatFruit(hana);

        AkumaNoMiObserver o4 = new AkumaNoMiObserver();
        robin.getObservers().add(o4);

        strawhat.getMembers().add(robin);
        strawhat.getMembers().add(chopper);

        strawhat.calculateCrewBounty();
        strawhat.calculateCrewSize();
        
        System.out.println("the " + strawhat.getCrewName() + " has arrived at " + alabasta.getName());
        System.out.println("the " + strawhat.getCrewName() + " has recruited " + robin.getName() + " and " + chopper.getName() + " and now has " + strawhat.getCrewSize() + " members");
        System.out.println();
        
        if (crocodile.getFruit() != null) {
            System.out.println(crocodile.getName() + " has the fruit: " + crocodile.getFruit().getFruitName());
        } else {
            System.out.println(crocodile.getName() + " currently has no fruit.");
        }

        if (suna.getUser() != null) {
            System.out.println("The " + suna.getFruitName() + " is being used by: " + suna.getUser().getName());
        } else {
            System.out.println("The " + suna.getFruitName() + " currently has no user.");
        }
        System.out.println();

        luffy.fight(crocodile);
        robin.fight(crocodile);
        crocodile.fight(robin);
        suna.becomeElement();
        crocodile.fight(luffy);
        luffy.fight(crocodile);

        if (crocodile.getFruit() != null) {
            System.out.println(crocodile.getName() + " has the fruit: " + crocodile.getFruit().getFruitName());
        } else {
            System.out.println(crocodile.getName() + " currently has no fruit.");
        }

        if (suna.getUser() != null) {
            System.out.println("The " + suna.getFruitName() + " is being used by: " + suna.getUser().getName());
        } else {
            System.out.println("The " + suna.getFruitName() + " currently has no user.");
        }
        System.out.println();

        luffy.increaseBounty(crocodile);

        System.out.println(luffy.getName() + " had your bounty increased to " + luffy.getBounty());
        System.out.println("");

        Island fishmen = new Island();
        fishmen.setLocation("Grand Line");
        fishmen.setName("Fishmen Island");
        fishmen.setRuler("Neptune");
        fishmen.setRulerFaction("Fishmen");

        Pirate jinbe = new Pirate();
        jinbe.setAge(44);
        jinbe.setBounty(76000000);
        jinbe.setHealth(90);
        jinbe.setHealthMax(90);
        jinbe.setIsAlive(true);
        jinbe.setName("Jinbe");
        jinbe.setRace("Fishmen");
        jinbe.setStrength(20);

        strawhat.setSail(fishmen);

        strawhat.getMembers().add(jinbe);

        strawhat.calculateCrewSize();
        strawhat.calculateCrewBounty();

        System.out.println("the " + strawhat.getCrewName() + " has arrived at " + fishmen.getName());
        System.out.println("the " + strawhat.getCrewName() + " has recruited " + jinbe.getName() + " and now has " + strawhat.getCrewSize() + " members" + " with a total bounty of: " + strawhat.getCrewBounty());

        System.out.println(" 2 years have passed");

        luffy.setAge(19);
        zoro.setAge(21);
        sanji.setAge(21);
        nami.setAge(19);
        usopp.setAge(19);
        robin.setAge(30);
        chopper.setAge(17);
        jinbe.setAge(46);

        Armament a1 = new Armament();
        a1.setUser(luffy);
        a1.setProficiency(2);
        a1.setPower(6);

        Observation ob1 = new Observation();
        ob1.setUser(luffy);

        Conqueror c = new Conqueror();
        c.setUser(luffy);


        luffy.setHakis(0, a1);
        luffy.setHakis(1, ob1);
        luffy.setHakis(2, c);

        Island egghead = new Island();
        egghead.setLocation("New World");
        egghead.setName("Egghead");
        egghead.setRuler("Vegapunk");
        egghead.setRulerFaction("World Government");
        
        Sea newWorld = new Sea();
        newWorld.setDangerLevel("Very High");
        newWorld.setName("New World");
        newWorld.getIslands().add(egghead);


        Marine kizaru = new Marine();
        kizaru.setAge(58);
        kizaru.setName("Borsalino");
        kizaru.setIsAlive(true);
        kizaru.setHealth(110);
        kizaru.setHealthMax(110);
        kizaru.setRace("Human");
        kizaru.setRank("Admiral");
        kizaru.setStrength(30);
        kizaru.setWillPower(70);
        kizaru.eatFruit(suna);

        AkumaNoMiObserver o5 = new AkumaNoMiObserver();
        kizaru.getObservers().add(o5);

        Armament a = new Armament();
        a.setUser(kizaru);
        a.setProficiency(2);
        a.setPower(5);

        Observation ob = new Observation();
        ob.setUser(kizaru);

        kizaru.setHakis(0, a);
        kizaru.setHakis(1, ob);

        System.out.println();

        if (kizaru.getFruit() != null) {
            System.out.println(kizaru.getName() + " has the fruit: " + kizaru.getFruit().getFruitName());
        } else {
            System.out.println(kizaru.getName() + " currently has no fruit.");
        }

        System.out.println();
        
        ob1.sensePower(kizaru);

        kizaru.fight(chopper);
        hito.transform();
        kizaru.fight(chopper);

        a.enhancedAttack(luffy);
        a1.enhancedAttack(kizaru);
        c.dominate(kizaru);
        System.out.println();

        luffy.setBounty(900000000);


        Island raftel = new Island();
        raftel.setLocation("New World");
        raftel.setName("Laugh tale");

        OnePiece onepiece = OnePiece.getInstance();
        onepiece.setDescription("The true treasure is the friends we make along the way");

        strawhat.setSail(raftel);

        System.out.println("the " + strawhat.getCrewName() + " arrives at " + raftel.getName() + " and find the One Piece");
        System.out.println("The One Piece is: " + onepiece.getDescription());


}
}