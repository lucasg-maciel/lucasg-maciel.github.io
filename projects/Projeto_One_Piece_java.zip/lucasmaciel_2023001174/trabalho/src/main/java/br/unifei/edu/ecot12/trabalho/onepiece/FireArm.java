package br.unifei.edu.ecot12.trabalho.onepiece;

public class FireArm extends Weapon{
    private int penetration;
    private int ammoCapacity;
    private int ammo;

    public void reload(){
        ammo = ammoCapacity;
    }

    public void fire(Human opponent){
        System.out.println(getOwner().getName() + " deals " + (penetration) + " damage!");
        opponent.takeDamage(penetration);
        ammo--;
    }

    public int getPenetration() {
        return penetration;
    }

    public void setPenetration(int penetration) {
        this.penetration = penetration;
    }

    public int getAmmoCapacity() {
        return ammoCapacity;
    }

    public void setAmmoCapacity(int ammoCapacity) {
        this.ammoCapacity = ammoCapacity;
    }

    public int getAmmo() {
        return ammo;
    }

    public void setAmmo(int ammo) {
        this.ammo = ammo;
    }


}
