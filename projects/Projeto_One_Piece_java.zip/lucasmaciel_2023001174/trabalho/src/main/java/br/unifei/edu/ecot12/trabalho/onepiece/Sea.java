package br.unifei.edu.ecot12.trabalho.onepiece;

import java.util.ArrayList;
import java.util.List;

public class Sea {
    private String name;
    private String climateBehavior;
    private String dangerLevel;
    private List<Island> islands = new ArrayList<Island>();

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getClimateBehavior() {
        return climateBehavior;
    }

    public void setClimateBehavior(String climateBehavior) {
        this.climateBehavior = climateBehavior;
    }

    public String getDangerLevel() {
        return dangerLevel;
    }

    public void setDangerLevel(String dangerLevel) {
        this.dangerLevel = dangerLevel;
    }

    public List<Island> getIslands() {
        return islands;
    }

    public void setIslands(List<Island> islands) {
        this.islands = islands;
    }


}   
