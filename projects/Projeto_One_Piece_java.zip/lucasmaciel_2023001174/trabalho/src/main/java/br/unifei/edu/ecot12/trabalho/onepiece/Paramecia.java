package br.unifei.edu.ecot12.trabalho.onepiece;

public class Paramecia extends AkumaNoMi{
    private String powerDescription;

    public String getPowerDescription() {
        return powerDescription;
    }

    public void setPowerDescription(String powerDescription) {
        this.powerDescription = powerDescription;
    }

}
