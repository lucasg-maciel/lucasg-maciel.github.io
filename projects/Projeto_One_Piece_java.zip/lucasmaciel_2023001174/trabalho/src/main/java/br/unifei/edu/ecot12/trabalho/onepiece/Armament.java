package br.unifei.edu.ecot12.trabalho.onepiece;

public class Armament extends Haki{
    private int power;

    public void enhancedAttack(Human opponent){
        System.out.println(getUser().getName() + " deals " + (getUser().getStrength() + (power*getProficiency())) + " damage!");
        opponent.takeDamage(getUser().getStrength() + (power*getProficiency()));
        
    }

    public int getPower() {
        return power;
    }

    public void setPower(int power) {
        this.power = power;
    }


}
